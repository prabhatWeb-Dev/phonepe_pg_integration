<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="shortcut icon" href="img/PhonePe_vertical-16158be8710408f3561e1d07d01d5d89.png" type="image/x-icon">
</head>
<body>
    <center>
        <h1>PhonePe Payment Gateway Integration</h1>
    </center>
</body>
</html>
<?php
    // create variable
    $api_key= "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399";
    $merchant_id= "PGTESTPAYUAT";
    $api_end_point= "/pg/v1/pay";
    $amount= 10;
    $salt_index= 1;
    // create pay load
    $sample_payload= array(
        "merchantId"=> $merchant_id,
        "merchantTransactionId"=> "MT7850590068188104", // transaction ID
        "merchantUserId"=> "MUID123", // transaction order ID
        "amount"=> $amount*100, // Amount multiply with 100
        "redirectUrl"=> "http://localhost/phonpe-payment-gateway-integration/response.php",
        "redirectMode"=> "REDIRECT",
        "callbackUrl"=> "http://localhost/phonpe-payment-gateway-integration/response.php",
        "mobileNumber"=> "9999999999",
        "paymentInstrument"=> [
            "type"=> "PAY_PAGE"
        ]
    );

    $json_encode= json_encode($sample_payload);
    $pay_load_main= base64_encode($json_encode);
    $request= json_encode(array("request"=> $pay_load_main));
    $payload= $pay_load_main."".$api_end_point."".$api_key;
    $sha256= hash("SHA256", $payload);
    $final_x_header= $sha256."###".$salt_index;
    //echo $final_x_header;

    // initiate client URL (CURL)
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $request,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "X-VERIFY: " .$final_x_header,
            "accept: application/json"
        ],
    ]);
    $respons= curl_exec($curl);
    $error= curl_error($curl);
    curl_close($curl);

    if ($error) {
        echo "cURL Error #:" . $error;
    }else{
        $json_decode($respons);
        print_r($json_decode);
    }



?>